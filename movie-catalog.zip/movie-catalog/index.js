const express = require("express");
const mysql = require("mysql2");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static("public")); // Serves frontend files from /public

// MySQL connection
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "12345", // ✅ your MySQL password
  database: "movies_db",
});

db.connect((err) => {
  if (err) {
    console.error("❌ MySQL connection failed:", err.message);
    return;
  }
  console.log("✅ Connected to MySQL database");
});

// Routes

// Get all movies
app.get("/movies", (req, res) => {
  db.query("SELECT * FROM movies", (err, results) => {
    if (err) {
      console.error("❌ Error fetching movies:", err);
      return res.status(500).send("Database error");
    }
    res.json(results);
  });
});

// Add a new movie
app.post("/movies", (req, res) => {
  const { title, director, genre, release_year, rating } = req.body;
  if (!title) {
    return res.status(400).json({ error: "Title is required" });
  }

  db.query(
    "INSERT INTO movies (title, director, genre, release_year, rating) VALUES (?, ?, ?, ?, ?)",
    [title, director, genre, release_year, rating],
    (err, result) => {
      if (err) {
        console.error("❌ Error inserting movie:", err);
        return res.status(500).send("Database error");
      }
      res.json({
        id: result.insertId,
        title,
        director,
        genre,
        release_year,
        rating,
      });
    }
  );
});

// Update a movie
app.put("/movies/:id", (req, res) => {
  const { id } = req.params;
  const { title, director, genre, release_year, rating } = req.body;

  db.query(
    "UPDATE movies SET title=?, director=?, genre=?, release_year=?, rating=? WHERE id=?",
    [title, director, genre, release_year, rating, id],
    (err, result) => {
      if (err) {
        console.error("❌ Error updating movie:", err);
        return res.status(500).send("Database error");
      }
      if (result.affectedRows === 0) {
        return res.status(404).json({ message: "Movie not found" });
      }
      res.json({ message: "✅ Movie updated successfully" });
    }
  );
});

// Delete a movie
app.delete("/movies/:id", (req, res) => {
  const { id } = req.params;
  db.query("DELETE FROM movies WHERE id=?", [id], (err, result) => {
    if (err) {
      console.error("❌ Error deleting movie:", err);
      return res.status(500).send("Database error");
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Movie not found" });
    }
    res.json({ message: "🗑️ Movie deleted successfully" });
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});

export default function BreedShow({ breed, onClose }) {
  if (!breed) return null;
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/40 p-4">
      <div className="w-full max-w-3xl rounded-2xl bg-white shadow-2xl overflow-hidden">
        <div className="grid md:grid-cols-2">
          <div className="bg-gray-100">
            {breed.imageUrl ? (
              <img src={breed.imageUrl} alt={breed.name} className="h-full w-full object-cover" />
            ) : (
              <div className="h-full w-full flex items-center justify-center text-sm text-gray-500 p-8">
                No image provided
              </div>
            )}
          </div>
          <div className="p-6">
            <h3 className="text-black font-bold mb-2">{breed.name}</h3>
            <div className="grid grid-cols-2 gap-2 text-sm text-black">
              <div><span className="font-medium">Group:</span> {breed.group || "—"}</div>
              <div><span className="font-medium">Size:</span> {breed.size || "—"}</div>
              <div><span className="font-medium">Life Span:</span> {breed.lifeSpan || "—"}</div>
              <div><span className="font-medium">Origin:</span> {breed.origin || "—"}</div>
            </div>
            {breed.temperament?.length ? (
              <div className="mt-3">
                <div className="text-sm font-medium mb-1 text-black">Temperament</div>
                <div className="flex flex-wrap gap-2">
                  {breed.temperament.map((t) => (
                    <span key={t} className="rounded-full border px-2 py-1 text-xs text-black">{t}</span>
                  ))}
                </div>
              </div>
            ) : null}
            {breed.description && (
              <p className="mt-4 text-sm text-gray-700">{breed.description}</p>
            )}
            <div className="mt-6 flex justify-end">
              <button onClick={onClose} className="rounded-xl bg-gray-900 text-white px-4 py-2">Close</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useMemo, useState } from "react";

export default function BreedList({ breeds, onView, onEdit, onDelete, onAdd }) {
  const [query, setQuery] = useState("");
  const [size, setSize] = useState("");
  const [group, setGroup] = useState("");
  const [sort, setSort] = useState("name-asc");

  const groups = useMemo(
    () => Array.from(new Set(breeds.map((b) => b.group).filter(Boolean))).sort(),
    [breeds]
  );

  const filtered = useMemo(() => {
    let out = [...breeds];
    if (query.trim()) {
      const q = query.toLowerCase();
      out = out.filter(
        (b) =>
          b.name.toLowerCase().includes(q) ||
          (b.description || "").toLowerCase().includes(q) ||
          (b.temperament || []).some((t) => t.toLowerCase().includes(q))
      );
    }
    if (size) out = out.filter((b) => b.size === size);
    if (group) out = out.filter((b) => b.group === group);

    switch (sort) {
      case "name-desc":
        out.sort((a, b) => b.name.localeCompare(a.name));
        break;
      case "size-asc":
        out.sort((a, b) => (a.size || "").localeCompare(b.size || ""));
        break;
      case "size-desc":
        out.sort((a, b) => (b.size || "").localeCompare(a.size || ""));
        break;
      default:
        out.sort((a, b) => a.name.localeCompare(b.name));
    }
    return out;
  }, [breeds, query, size, group, sort]);

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex flex-col md:flex-row md:items-end gap-3">
        <div className="flex-1">
          <label className="block text-sm font-medium mb-1 text-black">
            Search
          </label>
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by name, temperament, description…"
            className="w-full rounded-xl border p-2 text-black bg-white"
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1 text-black">
            Size
          </label>
          <select
            value={size}
            onChange={(e) => setSize(e.target.value)}
            className="rounded-xl border p-2 text-black bg-white"
          >
            <option value="">All</option>
            <option>Small</option>
            <option>Medium</option>
            <option>Large</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1 text-black">
            Group
          </label>
          <select
            value={group}
            onChange={(e) => setGroup(e.target.value)}
            className="rounded-xl border p-2 text-black bg-white"
          >
            <option value="">All</option>
            {groups.map((g) => (
              <option key={g}>{g}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1 text-black">
            Sort
          </label>
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value)}
            className="rounded-xl border p-2 text-black bg-white"
          >
            <option value="name-asc">Name ↑</option>
            <option value="name-desc">Name ↓</option>
            <option value="size-asc">Size ↑</option>
            <option value="size-desc">Size ↓</option>
          </select>
        </div>
        <div className="md:ml-auto">
          <button
            onClick={onAdd}
            className="w-full rounded-xl bg-indigo-600 px-4 py-2 text-white"
          >
            + Add Breed
          </button>
        </div>
      </div>

      {/* Grid */}
      {filtered.length === 0 ? (
        <div className="rounded-2xl border p-8 text-center text-gray-600 bg-white">
          No breeds yet. Click{" "}
          <span className="font-medium">“Add Breed”</span> to create your first
          record.
        </div>
      ) : (
        <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((b) => (
            <article
              key={b.id}
              className="rounded-2xl border shadow-sm overflow-hidden bg-white flex flex-col"
            >
              <div className="aspect-[16/10] bg-gray-100">
                {b.imageUrl ? (
                  <img
                    src={b.imageUrl}
                    alt={b.name}
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <div className="h-full w-full flex items-center justify-center text-sm text-gray-500">
                    No image
                  </div>
                )}
              </div>
              <div className="p-4 flex-1 flex flex-col">
                <h3 className="text-lg font-semibold text-black">{b.name}</h3>
                <div className="mt-1 text-xs text-gray-600 space-x-2">
                  {b.group && (
                    <span className="rounded-full border px-2 py-0.5">
                      {b.group}
                    </span>
                  )}
                  {b.size && (
                    <span className="rounded-full border px-2 py-0.5">
                      {b.size}
                    </span>
                  )}
                </div>
                {b.description && (
                  <p className="mt-2 text-sm text-gray-700 line-clamp-3">
                    {b.description}
                  </p>
                )}
                <div className="mt-4 grid grid-cols-3 gap-2">
                  <button
                    onClick={() => onView(b)}
                    className="rounded-xl border px-3 py-2 text-sm text-black bg-white hover:bg-indigo-50"
                  >
                    View
                  </button>
                  <button
                    onClick={() => onEdit(b)}
                    className="rounded-xl border px-3 py-2 text-sm text-black bg-white hover:bg-yellow-50"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => onDelete(b)}
                    className="rounded-xl bg-red-600 text-white px-3 py-2 text-sm hover:bg-red-700"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}

import { useState } from "react";

const sizes = ["Small", "Medium", "Large"];
const groups = [
  "Sporting",
  "Hound",
  "Working",
  "Terrier",
  "Toy",
  "Non-Sporting",
  "Herding",
  "Miscellaneous",
];

export default function BreedCreate({ onCancel, onCreate }) {
  const [form, setForm] = useState({
    name: "",
    group: "",
    size: "",
    lifeSpan: "",
    temperament: "",
    origin: "",
    imageUrl: "",
    description: "",
  });

  function handleChange(e) {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
  }

  function handleSubmit(e) {
    e.preventDefault();
    if (!form.name.trim()) return;
    const payload = {
      ...form,
      temperament: form.temperament
        ? form.temperament
            .split(",")
            .map((t) => t.trim())
            .filter(Boolean)
        : [],
    };
    onCreate(payload);
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      {/* Light themed modal */}
      <div className="w-full max-w-2xl rounded-2xl bg-white p-6 shadow-2xl text-black">
        <h2 className="text-2xl font-bold mb-4">Add New Breed</h2>
        <form
          onSubmit={handleSubmit}
          className="grid grid-cols-1 md:grid-cols-2 gap-4"
        >
          <div className="md:col-span-1">
            <label className="block text-sm font-medium mb-1">Name *</label>
            <input
              name="name"
              value={form.name}
              onChange={handleChange}
              required
              className="w-full rounded-xl border border-black p-2"
              placeholder="Labrador Retriever"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Group</label>
            <select
              name="group"
              value={form.group}
              onChange={handleChange}
              className="w-full rounded-xl border border-black p-2"
            >
              <option value="">Select…</option>
              {groups.map((g) => (
                <option key={g} value={g}>
                  {g}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Size</label>
            <select
              name="size"
              value={form.size}
              onChange={handleChange}
              className="w-full rounded-xl border border-black p-2"
            >
              <option value="">Select…</option>
              {sizes.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Life Span</label>
            <input
              name="lifeSpan"
              value={form.lifeSpan}
              onChange={handleChange}
              className="w-full rounded-xl border border-black p-2"
              placeholder="10–12 years"
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium mb-1">
              Temperament (comma-separated)
            </label>
            <input
              name="temperament"
              value={form.temperament}
              onChange={handleChange}
              className="w-full rounded-xl border border-black p-2"
              placeholder="Friendly, Outgoing, Gentle"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Origin</label>
            <input
              name="origin"
              value={form.origin}
              onChange={handleChange}
              className="w-full rounded-xl border border-black p-2"
              placeholder="Canada"
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium mb-1">Image URL</label>
            <input
              name="imageUrl"
              value={form.imageUrl}
              onChange={handleChange}
              className="w-full rounded-xl border border-black p-2"
              placeholder="https://..."
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium mb-1">Description</label>
            <textarea
              name="description"
              value={form.description}
              onChange={handleChange}
              rows={3}
              className="w-full rounded-xl border border-black p-2"
              placeholder="Short description…"
            />
          </div>
          <div className="md:col-span-2 flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onCancel}
              className="rounded-xl border border-black px-4 py-2"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-xl bg-indigo-600 px-4 py-2 text-white"
            >
              Create
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

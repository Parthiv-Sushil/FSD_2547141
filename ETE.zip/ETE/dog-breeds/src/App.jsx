import { useEffect, useMemo, useState } from "react";
import BreedList from "./components/BreedList.jsx";
import BreedCreate from "./components/BreedCreate.jsx";
import BreedEdit from "./components/BreedEdit.jsx";
import BreedShow from "./components/BreedShow.jsx";
import { loadBreeds, saveBreeds, uid } from "./lib/storage.js";
import { seedBreeds } from "./lib/seed.js";

export default function App() {
  const [breeds, setBreeds] = useState([]);
  const [showCreate, setShowCreate] = useState(false);
  const [editing, setEditing] = useState(null);
  const [viewing, setViewing] = useState(null);

  // Load from localStorage on mount; if empty, seed with a few records
  useEffect(() => {
    const initial = loadBreeds();
    if (initial.length === 0) {
      setBreeds(seedBreeds);
      saveBreeds(seedBreeds);
    } else {
      setBreeds(initial);
    }
  }, []);

  // Persist to localStorage when breeds change
  useEffect(() => {
    saveBreeds(breeds);
  }, [breeds]);

  function handleCreate(payload) {
    const newBreed = { id: uid(), ...payload };
    setBreeds((prev) => [newBreed, ...prev]);
    setShowCreate(false);
  }

  function handleUpdate(updated) {
    setBreeds((prev) => prev.map((b) => (b.id === updated.id ? updated : b)));
    setEditing(null);
  }

  function handleDelete(breed) {
    const ok = window.confirm(`Delete "${breed.name}"? This cannot be undone.`);
    if (!ok) return;
    setBreeds((prev) => prev.filter((b) => b.id !== breed.id));
  }

  const total = useMemo(() => breeds.length, [breeds]);

  return (
    <div className="min-h-screen bg-black text-gray-100">
      <header className="sticky top-0 z-10 border-b border-gray-800 bg-gray-900/90 backdrop-blur">
        <div className="mx-auto max-w-6xl px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-2xl bg-indigo-600 text-white grid place-content-center text-lg font-bold">
              🐶
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-bold text-white">
                Dog Breed Manager
              </h1>
            </div>
          </div>
          <button
            onClick={() => setShowCreate(true)}
            className="rounded-xl bg-indigo-600 px-4 py-2 text-white hover:bg-indigo-500 transition"
          >
            + Add Breed
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-6">
        <div className="mb-4 text-sm text-gray-400">
          <span className="rounded-full border border-gray-700 px-2 py-1">
            Total: {total}
          </span>
        </div>

        <BreedList
          breeds={breeds}
          onView={(b) => setViewing(b)}
          onEdit={(b) => setEditing(b)}
          onDelete={handleDelete}
          onAdd={() => setShowCreate(true)}
        />
      </main>

      <footer className="mx-auto max-w-6xl px-4 py-8 text-center text-xs text-gray-500 border-t border-gray-800">
        2547141 1MCA-A
      </footer>

      {showCreate && (
        <BreedCreate
          onCancel={() => setShowCreate(false)}
          onCreate={handleCreate}
        />
      )}
      {editing && (
        <BreedEdit
          breed={editing}
          onCancel={() => setEditing(null)}
          onUpdate={handleUpdate}
        />
      )}
      {viewing && (
        <BreedShow breed={viewing} onClose={() => setViewing(null)} />
      )}
    </div>
  );
}

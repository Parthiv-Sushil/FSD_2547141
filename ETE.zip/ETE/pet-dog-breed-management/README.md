# Pet Dog Breed Management System

This project is a Pet Dog Breed Management System built with React and Vite, featuring full CRUD functionality for managing dog breeds. The application allows users to create, read, update, and delete dog breed entries, providing a user-friendly interface styled with Tailwind CSS.

## Features

- **Create Dog Breed**: Add new dog breeds to the system using a form.
- **Edit Dog Breed**: Update existing dog breed information.
- **List Dog Breeds**: View a list of all dog breeds in the system.
- **Show Dog Breed**: Display detailed information about a selected dog breed.
- **Responsive Design**: The application is styled with Tailwind CSS for a modern and responsive user interface.

## Technologies Used

- React
- Vite
- TypeScript
- Tailwind CSS
- React Router

## Getting Started

To get a local copy up and running, follow these simple steps:

1. **Clone the repository**:
   ```bash
   git clone https://github.com/yourusername/pet-dog-breed-management.git
   ```

2. **Navigate to the project directory**:
   ```bash
   cd pet-dog-breed-management
   ```

3. **Install dependencies**:
   ```bash
   npm install
   ```

4. **Run the application**:
   ```bash
   npm run dev
   ```

5. **Open your browser** and go to `http://localhost:3000` to see the application in action.

## Folder Structure

```
pet-dog-breed-management
├── src
│   ├── components          # Contains all the React components
│   ├── pages               # Contains the main pages of the application
│   ├── App.tsx             # Main application component with routing
│   ├── main.tsx            # Entry point of the application
│   └── styles              # Contains global styles
├── public
│   └── favicon.ico         # Favicon for the application
├── index.html              # Main HTML file
├── package.json            # NPM configuration file
├── postcss.config.js       # PostCSS configuration for Tailwind CSS
├── tailwind.config.js      # Tailwind CSS configuration
├── tsconfig.json           # TypeScript configuration
└── README.md               # Project documentation
```

## Contributing

Contributions are welcome! Please feel free to submit a pull request or open an issue for any suggestions or improvements.

## License

This project is licensed under the MIT License. See the LICENSE file for details.
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Home from './pages/Home';
import NotFound from './pages/NotFound';
import BreedList from './components/BreedList';
import BreedCreate from './components/BreedCreate';
import BreedEdit from './components/BreedEdit';
import BreedShow from './components/BreedShow';

const App = () => {
  return (
    <Router>
      <Switch>
        <Route path="/" exact component={Home} />
        <Route path="/breeds" exact component={BreedList} />
        <Route path="/breeds/create" component={BreedCreate} />
        <Route path="/breeds/edit/:id" component={BreedEdit} />
        <Route path="/breeds/:id" component={BreedShow} />
        <Route component={NotFound} />
      </Switch>
    </Router>
  );
};

export default App;
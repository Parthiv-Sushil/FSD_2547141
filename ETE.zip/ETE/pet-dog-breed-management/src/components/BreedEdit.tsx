import React, { useState, useEffect } from 'react';

interface BreedEditProps {
  breed: {
    id: string;
    name: string;
    description: string;
    imageUrl: string;
  };
  onUpdate: (updatedBreed: { id: string; name: string; description: string; imageUrl: string }) => void;
}

const BreedEdit: React.FC<BreedEditProps> = ({ breed, onUpdate }) => {
  const [name, setName] = useState(breed.name);
  const [description, setDescription] = useState(breed.description);
  const [imageUrl, setImageUrl] = useState(breed.imageUrl);

  useEffect(() => {
    setName(breed.name);
    setDescription(breed.description);
    setImageUrl(breed.imageUrl);
  }, [breed]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdate({ id: breed.id, name, description, imageUrl });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700">Breed Name</label>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="mt-1 block w-full border border-gray-300 rounded-md p-2"
          required
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700">Description</label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="mt-1 block w-full border border-gray-300 rounded-md p-2"
          required
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700">Image URL</label>
        <input
          type="text"
          value={imageUrl}
          onChange={(e) => setImageUrl(e.target.value)}
          className="mt-1 block w-full border border-gray-300 rounded-md p-2"
          required
        />
      </div>
      <button type="submit" className="w-full bg-blue-500 text-white p-2 rounded-md">
        Update Breed
      </button>
    </form>
  );
};

export default BreedEdit;
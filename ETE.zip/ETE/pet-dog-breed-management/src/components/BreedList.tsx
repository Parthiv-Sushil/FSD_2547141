import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const BreedList = () => {
    const [breeds, setBreeds] = useState([]);

    useEffect(() => {
        const fetchBreeds = async () => {
            const response = await fetch('/api/breeds'); // Adjust the API endpoint as necessary
            const data = await response.json();
            setBreeds(data);
        };

        fetchBreeds();
    }, []);

    const handleDelete = async (id) => {
        await fetch(`/api/breeds/${id}`, {
            method: 'DELETE',
        });
        setBreeds(breeds.filter(breed => breed.id !== id));
    };

    return (
        <div className="container mx-auto p-4">
            <h1 className="text-2xl font-bold mb-4">Dog Breeds</h1>
            <Link to="/create" className="bg-blue-500 text-white px-4 py-2 rounded mb-4 inline-block">Add New Breed</Link>
            <ul className="space-y-4">
                {breeds.map(breed => (
                    <li key={breed.id} className="border p-4 rounded flex justify-between items-center">
                        <div>
                            <h2 className="text-xl font-semibold">{breed.name}</h2>
                            <p>{breed.description}</p>
                        </div>
                        <div>
                            <Link to={`/edit/${breed.id}`} className="text-blue-500 mr-4">Edit</Link>
                            <button onClick={() => handleDelete(breed.id)} className="text-red-500">Delete</button>
                        </div>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default BreedList;
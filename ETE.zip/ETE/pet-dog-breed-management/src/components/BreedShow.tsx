import React from 'react';

interface BreedShowProps {
    breed: {
        id: number;
        name: string;
        description: string;
        size: string;
        lifespan: string;
        imageUrl: string;
    };
}

const BreedShow: React.FC<BreedShowProps> = ({ breed }) => {
    return (
        <div className="max-w-md mx-auto bg-white rounded-xl shadow-md overflow-hidden md:max-w-2xl my-4">
            <div className="md:flex">
                <div className="md:shrink-0">
                    <img className="h-48 w-full object-cover md:w-48" src={breed.imageUrl} alt={breed.name} />
                </div>
                <div className="p-8">
                    <h2 className="text-xl font-bold">{breed.name}</h2>
                    <p className="mt-2 text-gray-500">{breed.description}</p>
                    <p className="mt-2 text-gray-700"><strong>Size:</strong> {breed.size}</p>
                    <p className="mt-2 text-gray-700"><strong>Lifespan:</strong> {breed.lifespan}</p>
                </div>
            </div>
        </div>
    );
};

export default BreedShow;